# Design For Visual System Log Book

Name : Zihan Wang

[Lab 1 Log Book](https://www.notion.so/Lab-1-Log-Book-192843b8c58d80c09742e994f8aebcad?pvs=21)

[Lab 2 Log Book](https://www.notion.so/Lab-2-Log-Book-196843b8c58d8050ae98e4da2e3a087c?pvs=21)

[Lab 3 Log Book](https://www.notion.so/Lab-3-Log-Book-196843b8c58d804092efcd6f6337bd1d?pvs=21)

[Lab 4 Log Book](https://www.notion.so/Lab-4-Log-Book-194843b8c58d80048888e46a6f50ee52?pvs=21)